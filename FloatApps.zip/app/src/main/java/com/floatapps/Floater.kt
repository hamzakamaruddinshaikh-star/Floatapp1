package com.floatapps

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.widget.Toast

object Floater {
    private var n = 0

    /** Plain floating (freeform) window, no Shizuku needed. Requires freeform enabled in Developer options. */
    fun launch(c: Context, pkg: String, size: Int): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        val m = c.resources.displayMetrics
        val (fw, fh) = when (size) {
            0 -> 0.60f to 0.35f
            1 -> 0.90f to 0.55f
            else -> 0.95f to 0.80f
        }
        val w = (m.widthPixels * fw).toInt()
        val h = (m.heightPixels * fh).toInt()
        val off = (n++ % 4) * (28 * m.density).toInt()
        val l = ((m.widthPixels - w) / 2 + off).coerceAtMost(m.widthPixels - w)
        val t = ((m.heightPixels * 0.08f).toInt() + off).coerceAtMost(m.heightPixels - h)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i, ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h)).toBundle())
        return true
    }
}

/** Invisible activity behind home-screen shortcuts: opens a live tile (or floating window), then closes. */
class FloatLaunchActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg")
        if (pkg != null) {
            if (intent.getBooleanExtra("live", false)) {
                startForegroundService(
                    Intent(this, KeepAliveService::class.java)
                        .putExtra("pkg", pkg).putExtra("label", intent.getStringExtra("label"))
                )
            } else if (!Floater.launch(this, pkg, intent.getIntExtra("size", 1))) {
                Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show()
            }
        }
        finish()
    }
}
