package com.floatapps

import android.app.Activity
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.os.IBinder
import android.widget.Toast

object Floater {
    val sizes = arrayOf("Small", "Medium", "Large")
    private var n = 0

    /** Starts [pkg] in a floating (freeform) window. Needs freeform enabled in Developer options. */
    fun launch(c: Context, pkg: String, size: Int): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        val m = c.resources.displayMetrics
        val (fw, fh) = when (size) {
            0 -> 0.60f to 0.35f
            1 -> 0.90f to 0.55f
            else -> 0.95f to 0.80f
        }
        val w = (m.widthPixels * fw).toInt()
        val h = (m.heightPixels * fh).toInt()
        val off = (n++ % 4) * (28 * m.density).toInt() // cascade so windows don't stack exactly
        val l = ((m.widthPixels - w) / 2 + off).coerceAtMost(m.widthPixels - w)
        val t = ((m.heightPixels * 0.08f).toInt() + off).coerceAtMost(m.heightPixels - h)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i, ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h)).toBundle())
        return true
    }
}

/** Invisible activity behind the home-screen shortcuts: opens the app as a floating window, then closes. */
class FloatLaunchActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.getStringExtra("pkg")
        val size = intent.getIntExtra("size", 1)
        if (pkg != null && !Floater.launch(this, pkg, size)) {
            Toast.makeText(this, "Can't open that app", Toast.LENGTH_SHORT).show()
        }
        startForegroundService(Intent(this, KeepAliveService::class.java))
        finish()
    }
}

/** Keeps Float Apps' process alive with an ongoing notification. */
class KeepAliveService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("keep", "Float Apps", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(
            1,
            Notification.Builder(this, "keep")
                .setContentTitle("Float Apps is running")
                .setContentText("Tap to open")
                .setSmallIcon(android.R.drawable.ic_menu_agenda)
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
        )
        return START_STICKY
    }
}
