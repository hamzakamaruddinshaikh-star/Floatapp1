package com.floatapps

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        startForegroundService(Intent(this, KeepAliveService::class.java))

        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        val pad = (16 * resources.displayMetrics.density).toInt()
        status = TextView(this).apply { textSize = 14f }
        val dev = Button(this).apply {
            text = "1. Open Developer options"
            setOnClickListener {
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (e: Exception) { toast("Settings > About phone > tap Build number 7 times") }
            }
        }
        val bat = Button(this).apply {
            text = "2. Battery: let apps run in background"
            setOnClickListener { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        }
        val list = ListView(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, apps.map { it.second })
            setOnItemClickListener { _, _, i, _ -> choose(apps[i].first, apps[i].second) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(status); addView(dev); addView(bat)
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    override fun onResume() {
        super.onResume()
        fun on(k: String) = Settings.Global.getInt(contentResolver, k, 0) == 1
        val ff = on("enable_freeform_support") || packageManager.hasSystemFeature("android.software.freeform_window_management")
        status.text = "Freeform windows: ${if (ff) "ON" else "OFF"}\n" +
            "Force resizable: ${if (on("force_resizable_activities")) "ON" else "OFF"}\n\n" +
            "In Developer options turn on \"Enable freeform windows\" and \"Force activities to be resizable\", then reboot once. " +
            "(No Developer options? About phone > tap Build number 7 times.)\n\n" +
            "Then pick an app below. Close it first if it's already open."
    }

    private fun choose(pkg: String, label: String) {
        var size = 1
        AlertDialog.Builder(this).setTitle(label)
            .setSingleChoiceItems(Floater.sizes, 1) { _, w -> size = w }
            .setPositiveButton("Open now") { _, _ -> if (!Floater.launch(this, pkg, size)) toast("Can't open that app") }
            .setNeutralButton("Pin to home") { _, _ -> pin(pkg, label, size) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pin(pkg: String, label: String, size: Int) {
        val sm = getSystemService(ShortcutManager::class.java)
        if (!sm.isRequestPinShortcutSupported) return toast("Your launcher can't pin shortcuts")
        val d = packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 192, 192)
        d.draw(Canvas(bmp))
        val i = Intent(this, FloatLaunchActivity::class.java)
            .setAction(Intent.ACTION_VIEW).putExtra("pkg", pkg).putExtra("size", size)
        sm.requestPinShortcut(
            ShortcutInfo.Builder(this, "$pkg:$size").setShortLabel(label)
                .setIcon(Icon.createWithBitmap(bmp)).setIntent(i).build(), null
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
