package com.floatapps

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val pm = packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        val pad = (16 * resources.displayMetrics.density).toInt()
        status = TextView(this)
        val list = ListView(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, apps.map { it.second })
            setOnItemClickListener { _, _, i, _ -> choose(apps[i].first, apps[i].second) }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(status)
            addView(btn("1. Allow display over other apps") { overlaySettings() })
            addView(btn("2. Battery: let apps run in background") {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            })
            addView(btn("Developer options (floating windows only)") {
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (e: Exception) { toast("About phone > tap Build number 7 times") }
            })
            addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    override fun onResume() {
        super.onResume()
        val sz = try {
            if (!Shizuku.pingBinder()) "NOT running (start it via Wireless debugging)"
            else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) "ready" else "running, tap an app to allow"
        } catch (e: Throwable) { "NOT running (start it via Wireless debugging)" }
        status.text = "Shizuku: $sz\nOverlay: ${if (Settings.canDrawOverlays(this)) "ON" else "OFF"}\n\nPick an app below. A live tile keeps the app running while the tile is open (use the size button to shrink it)."
    }

    private fun overlaySettings() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun ready(): Boolean {
        if (!Settings.canDrawOverlays(this)) { overlaySettings(); return false }
        if (!Shizuku.pingBinder()) { toast("Start Shizuku first (open the Shizuku app)"); return false }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) { Shizuku.requestPermission(1); return false }
        return true
    }

    private fun choose(pkg: String, label: String) {
        AlertDialog.Builder(this).setTitle(label)
            .setItems(arrayOf("Live tile now", "Floating window (no Shizuku)", "Pin live tile to home")) { _, w ->
                when (w) {
                    0 -> if (ready()) startForegroundService(
                        Intent(this, KeepAliveService::class.java).putExtra("pkg", pkg).putExtra("label", label)
                    )
                    1 -> if (!Floater.launch(this, pkg, 1)) toast("Can't open that app")
                    else -> pin(pkg, label)
                }
            }.show()
    }

    private fun pin(pkg: String, label: String) {
        val sm = getSystemService(ShortcutManager::class.java)
        if (!sm.isRequestPinShortcutSupported) return toast("Your launcher can't pin shortcuts")
        val d = packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 192, 192)
        d.draw(Canvas(bmp))
        val i = Intent(this, FloatLaunchActivity::class.java).setAction(Intent.ACTION_VIEW)
            .putExtra("pkg", pkg).putExtra("label", label).putExtra("live", true)
        sm.requestPinShortcut(
            ShortcutInfo.Builder(this, "$pkg:live").setShortLabel(label)
                .setIcon(Icon.createWithBitmap(bmp)).setIntent(i).build(), null
        )
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
