package com.floatapps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.InputEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

/** Runs inside Shizuku's shell process (adb-level rights): launches apps on the hidden display and injects touches. */
class ShellImpl : IShell.Stub() {
    private var down = 0L

    override fun destroy() { System.exit(0) }

    override fun exec(cmd: String): String {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", "$cmd 2>&1"))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return out
    }

    override fun touch(displayId: Int, action: Int, x: Float, y: Float) {
        try {
            val now = SystemClock.uptimeMillis()
            if (action == MotionEvent.ACTION_DOWN) down = now
            val e = MotionEvent.obtain(down, now, action, x, y, 0)
            e.source = InputDevice.SOURCE_TOUCHSCREEN
            InputEvent::class.java.getMethod("setDisplayId", Int::class.javaPrimitiveType).invoke(e, displayId)
            val im = Class.forName("android.hardware.input.InputManager").getMethod("getInstance").invoke(null)!!
            im.javaClass.getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType).invoke(im, e, 0)
            e.recycle()
        } catch (t: Throwable) { }
    }
}

/** One live app: a hidden virtual screen mirrored into a draggable overlay window. */
class Tile(
    private val ctx: Context, private val pkg: String, label: String,
    private val sh: IShell, private val onClose: (Tile) -> Unit
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private val dm = ctx.getSystemService(DisplayManager::class.java)
    private var dw = 540
    private var dh = 960
    private var si = 1
    private val scales = floatArrayOf(0.5f, 0.75f, 1f, 0.2f)
    private var vd: VirtualDisplay? = null
    private var st: SurfaceTexture? = null
    private val tex = TextureView(ctx)
    private val root = LinearLayout(ctx)
    private val lp = WindowManager.LayoutParams(
        -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 250 }

    private fun btn(t: String, f: () -> Unit) = TextView(ctx).apply {
        text = t; textSize = 18f; setTextColor(-1); setPadding(24, 12, 24, 12); setOnClickListener { f() }
    }

    private fun relayout() {
        val w = (ctx.resources.displayMetrics.widthPixels * scales[si]).toInt()
        tex.layoutParams = LinearLayout.LayoutParams(w, w * dh / dw)
    }

    private fun rotate() {
        val t = dw; dw = dh; dh = t
        st?.setDefaultBufferSize(dw, dh)
        vd?.resize(dw, dh, 240)
        relayout()
    }

    fun close() {
        vd?.release(); vd = null
        try { wm.removeView(root) } catch (e: Exception) { }
        onClose(this)
    }

    init {
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xEE101010.toInt())
        val title = TextView(ctx).apply { text = "⠿ $label"; setTextColor(-1); setPadding(16, 12, 16, 12) }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(root, lp)
                }
            }
            true
        }
        val bar = LinearLayout(ctx)
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn("⤢") { si = (si + 1) % scales.size; relayout() })
        bar.addView(btn("↻") { rotate() })
        bar.addView(btn("✕") { close() })
        root.addView(bar)
        root.addView(tex)
        relayout()

        tex.setOnTouchListener { v, e ->
            val d = vd
            if (d != null && e.actionMasked in 0..3) {
                try { sh.touch(d.display.displayId, e.actionMasked, e.x * dw / v.width, e.y * dh / v.height) } catch (t: Throwable) { }
            }
            true
        }
        tex.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) {
                st = s
                s.setDefaultBufferSize(dw, dh)
                // OWN_CONTENT_ONLY | PRESENTATION | DESTROY_CONTENT_ON_REMOVAL
                val d = dm.createVirtualDisplay("float-$pkg", dw, dh, 240, Surface(s), (1 shl 3) or (1 shl 1) or (1 shl 8))
                vd = d
                val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString() ?: return
                val id = d.display.displayId
                Thread {
                    val o = try {
                        sh.exec("settings put global force_resizable_activities 1; am start --display $id -n $comp")
                    } catch (t: Throwable) { t.toString() }
                    if (!o.contains("Starting") || o.contains("rror")) {
                        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, o.take(300), Toast.LENGTH_LONG).show() }
                    }
                }.start()
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        wm.addView(root, lp)
    }
}

/** Foreground service: owns the Shizuku shell connection and all live tiles, so they keep running. */
class KeepAliveService : Service() {
    private var sh: IShell? = null
    private var binding = false
    private val pending = mutableListOf<Pair<String, String>>()
    private val tiles = mutableListOf<Tile>()

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            sh = IShell.Stub.asInterface(b)
            val p = pending.toList(); pending.clear()
            p.forEach { open(it.first, it.second) }
        }
        override fun onServiceDisconnected(n: ComponentName) { sh = null; binding = false }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("keep", "Float Apps", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(
            1,
            Notification.Builder(this, "keep")
                .setContentTitle("Float Apps is running")
                .setContentText("Tap to open")
                .setSmallIcon(android.R.drawable.ic_menu_agenda)
                .setContentIntent(pi).setOngoing(true).build()
        )
        i?.getStringExtra("pkg")?.let { open(it, i.getStringExtra("label") ?: it) }
        return START_STICKY
    }

    private fun open(pkg: String, label: String) {
        if (!Settings.canDrawOverlays(this) || !Shizuku.pingBinder() ||
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Open Float Apps and finish setup (overlay + Shizuku)", Toast.LENGTH_LONG).show()
            return
        }
        val s = sh
        if (s != null) { tiles += Tile(this, pkg, label, s) { tiles -= it }; return }
        pending += pkg to label
        if (!binding) {
            binding = true
            Shizuku.bindUserService(
                Shizuku.UserServiceArgs(ComponentName(packageName, ShellImpl::class.java.name))
                    .processNameSuffix("shell").daemon(false).version(1), conn
            )
        }
    }

    override fun onDestroy() {
        tiles.toList().forEach { it.close() }
        super.onDestroy()
    }
}
