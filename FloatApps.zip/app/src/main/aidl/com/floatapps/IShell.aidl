package com.floatapps;

interface IShell {
    void destroy() = 16777114;
    String exec(String cmd) = 1;
    oneway void touch(int displayId, int action, float x, float y) = 2;
}
